# Signed Exponential Random Graph Models for Static and Dynamic Network

------------

R package to estimate, simulate, and assess the fit of Signed Exponential Random Graph Models!
